# __init__.py
from .rules import add, multiply

